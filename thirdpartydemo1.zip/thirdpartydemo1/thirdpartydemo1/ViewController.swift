//
//  ViewController.swift
//  thirdpartydemo1
//
//  Created by mic-student on 9/14/19.
//  Copyright © 2019 hmp. All rights reserved.
//

import UIKit
import NVActivityIndicatorView
import Kingfisher


class ViewController: UIViewController {
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    var busyView:NVActivityIndicatorView?

    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        showBusy()
        
    }
    
    func setup(){
        
        let busyFrame = CGRect(x:20, y:20,width:100,height:100)
        busyView = NVActivityIndicatorView(frame:busyFrame)
        busyView?.type = .pacman
        busyView?.color = UIColor.blue
        //view.addSubview(busyView)
        busyView?.center = view.center
        //busyView.startAnimating()
        
        
        let urlString = "https://images.unsplash.com/photo-1533158307587-828f0a76ef46?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=667&q=80"
        let url = URL(string: urlString)
        imageView.kf.indicatorType = .activity
        imageView.kf.setImage(with:url)
    }
    
    func showBusy(){
        view.addSubview(busyView!)
        busyView?.startAnimating()
    }
    
    func hideBusy(){
        busyView?.stopAnimating()
        busyView?.removeFromSuperview()
    }
    


}

